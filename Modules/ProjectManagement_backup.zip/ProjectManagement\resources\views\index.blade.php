<x-projectmanagement::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('projectmanagement.name') !!}</p>
</x-projectmanagement::layouts.master>
