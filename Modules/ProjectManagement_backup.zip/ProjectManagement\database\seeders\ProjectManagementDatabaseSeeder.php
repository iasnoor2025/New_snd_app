<?php

namespace Modules\ProjectManagement\Database\Seeders;

use Illuminate\Database\Seeder;

class ProjectManagementDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
