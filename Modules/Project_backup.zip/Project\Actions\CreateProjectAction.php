<?php

namespace Modules\Project\Actions;

use Modules\Project\Domain\DTOs\ProjectDTO;
use Modules\Project\Services\ProjectService;
use Modules\Project\Events\ProjectCreated;

class CreateProjectAction
{
    public function __construct(
        protected ProjectService $projectService
    ) {}

    public function execute(ProjectDTO $dto): void
    {
        $project = $this->projectService->createProject($dto);

        // Dispatch event
        event(new ProjectCreated($project));

        // Calculate initial progress
        $this->projectService->updateProjectProgress($project);
    }
}
