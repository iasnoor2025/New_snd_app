<?php

use Illuminate\Support\Facades\Route;
use Modules\Project\Http\Controllers\ProjectController;
use Inertia\Inertia;

Route::middleware(['auth', 'verified'])->group(function () {
    Route::resource('projects', ProjectController::class)->names('project');
});

Route::middleware(['web', 'auth'])->group(function () {
    Route::get('/projects', function () {
        return Inertia::render('Projects', [
            'projects' => \Modules\Project\Domain\Project::with('manager')->get(),
            'managers' => \Modules\Employee\Domain\Employee::select('id', 'name')->get(),
        ]);
    })->name('projects.index');
});
