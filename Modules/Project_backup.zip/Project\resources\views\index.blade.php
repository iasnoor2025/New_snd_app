<x-project::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('project.name') !!}</p>
</x-project::layouts.master>
