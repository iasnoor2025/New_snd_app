<?php

namespace Modules\Project\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Modules\Project\Domain\DTOs\ProjectDTO;
use Modules\Project\Services\ProjectService;
use Modules\Employee\Domain\Employee;

class ProjectController extends Controller
{
    public function __construct(
        protected ProjectService $projectService
    ) {}

    public function index(): JsonResponse
    {
        $projects = $this->projectService->getAllProjects();
        return response()->json($projects);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'required|string',
            'start_date' => 'required|date',
            'end_date' => 'nullable|date|after:start_date',
            'status' => 'required|string|in:active,completed,on_hold,cancelled',
            'budget' => 'required|numeric|min:0',
            'manager_id' => 'required|exists:employees,id',
            'client_name' => 'required|string|max:255',
            'client_contact' => 'required|string|max:255',
            'priority' => 'required|string|in:high,medium,low',
        ]);

        $project = $this->projectService->createProject(ProjectDTO::fromArray($validated));
        return response()->json($project, 201);
    }

    public function show(int $id): JsonResponse
    {
        $project = $this->projectService->getProject($id);
        if (!$project) {
            return response()->json(['message' => 'Project not found'], 404);
        }
        return response()->json($project);
    }

    public function update(Request $request, int $id): JsonResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'required|string',
            'start_date' => 'required|date',
            'end_date' => 'nullable|date|after:start_date',
            'status' => 'required|string|in:active,completed,on_hold,cancelled',
            'budget' => 'required|numeric|min:0',
            'manager_id' => 'required|exists:employees,id',
            'client_name' => 'required|string|max:255',
            'client_contact' => 'required|string|max:255',
            'priority' => 'required|string|in:high,medium,low',
        ]);

        $project = $this->projectService->updateProject($id, ProjectDTO::fromArray($validated));
        return response()->json($project);
    }

    public function destroy(int $id): JsonResponse
    {
        $success = $this->projectService->deleteProject($id);
        if (!$success) {
            return response()->json(['message' => 'Project not found'], 404);
        }
        return response()->json(null, 204);
    }

    public function getManagers(): JsonResponse
    {
        $managers = Employee::select('id', 'name')->get();
        return response()->json($managers);
    }
}
